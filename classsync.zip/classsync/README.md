# ClassSync (HTML + basic Java backend)

Needs Java 11 or newer. No libraries, no Maven.

    cd classsync
    java Server.java

Open http://localhost:8080

- Data is saved on the server in `data/classsync.json`.
- Other devices on the same Wi-Fi can open `http://<your-pc-ip>:8080`; student check-in codes then work across devices.
- If the server is off, the page still works and saves in the browser only.
- Demo logins: Prof. Meera Joshi / teacher123, Aman Sharma / student123. Staff key: STAFF2026.

Basic-level limits: login and the staff key are still checked in the browser, and the whole data file is saved at once (last save wins).
